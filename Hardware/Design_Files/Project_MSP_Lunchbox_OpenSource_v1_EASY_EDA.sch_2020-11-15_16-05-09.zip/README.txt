This the adaptation of the schematic and PCB layout diagram of the MSP430 Lunchbox, The original ones are borrowed from a NPTEL course (https://onlinecourses.nptel.ac.in/noc20_ee98/course) and their Git repository (https://github.com/ticepd/EmbSysDesign_NPTEL_Course). And where all their documentation is present is at : https://lunchbox.sincgrid.com/docs/build/html/index.html and all credits goes to them for creating these all. 
Also this is unofficial            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。